/*******************************************************************************
 engine.h
 Programmer: Chuck Bolin, 2003
 Purpose:  Miscellaneous engine stuff
*******************************************************************************/
#ifndef _ENGINE_ENGINE_H
#define _ENGINE_ENGINE_H




#endif _ENGINE_ENGINE_H


