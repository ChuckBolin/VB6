/*********************************************************************
 PROGRAM - Written by Chuck Bolin
 This program uses the accompanying Grace Engine v0.1
*********************************************************************/

//Includes files
#define GLUT_DISABLE_ATEXIT_HACK
#include <gl\gl.h>
#include <gl\glut.h>
#include <gl\glu.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <vector>
#include <ctime>
#include "eventlog.h"
#include "program.h"
#include "fperson.h"
#include "graphics.h"
#include "bitmap.h"
#include "mymath.h"
#include "gameobj.h"
#include "engine.h"

using namespace std;

//****************************************************************************
//  Function prototypes
//****************************************************************************
 void LoadFont(void);

//****************************************************************************
//  Global Variables and constants
//****************************************************************************
PROGRAMINFO prog;     //stores program details..name, version, email, etc.

int gnMouseSelect;  //returns number equal to selection


//****************************************************************************
//  Initialization
//****************************************************************************


//************************************
//Initialize objects and variables
//************************************
void InitializeVariables()
{
  //initialize graphics
  gGraphics.near_view = .01;
  gGraphics.far_view = 200;
  gGraphics.view_angle = 45;
  
  //initialize first person
  gFPerson.Initialize(0,1.75,0,0,0,-1,0,1,0);
   
  //program specific information
  prog.version_number = gProgram.SetVersion("0.1");
  prog.program_name = gProgram.SetProgramName("Grace Engine");
  prog.program_description = gProgram.SetProgramDescription("This is a basic program.");
  prog.revision_date = gProgram.SetRevisionDate("01.16.03");
  prog.programmer_name = gProgram.SetProgrammerName("Chuck Bolin");
  prog.programmer_email = gProgram.SetProgrammerEmail("cbolin@dycon.com");
  prog.programmer_URL = gProgram.SetProgrammerURL("http://www.clg-net.com");
  prog.help_file = gProgram.SetHelpFile("help.htm");
  
  //datalog info
  gEventLog.LogData("Version: " + prog.version_number, 0);
  gEventLog.LogData("Program: " + prog.program_name,0);
  gEventLog.LogData("Description: " + prog.program_description,0);
  gEventLog.LogData("Revision Date: " + prog.revision_date,0);
  gEventLog.LogData("Programmer: " + prog.programmer_name,0);
  gEventLog.LogData("Email: " + prog.programmer_email,0);
  gEventLog.LogData("URL: " + prog.programmer_URL,0);
  gEventLog.LogData("Help file: " + prog.help_file,0);

  //load font info
  int ret = gGraphics.CreateFont(2);
  if (ret == 0){
    gEventLog.LogData("Font bitmap not found!", 0);
  }
  gGraphics.LoadFont();
  gEventLog.LogData("Font loaded",0);

  //game program specifics
  gGame.SetTimeFactor(1.0);
  gGame.SetGameMode(GAMEMODE_PLAY);
}

string FloatToString(float n){
  char buffer[50];
  ostrstream Str(buffer, 50);
  Str << n << ends;
  string mynum(Str.str());
  return mynum;
}

//****************************************************************************
//  Graphics
//****************************************************************************




//*******************************
// D R A W 2 D  P A N E L
// status = 0, not transparent
// status = 1, transparent
//*******************************
void Draw2DPanel(int x,int y, int w, int h, float r, float g, float b,
   int status, float trans)
{
  glPushMatrix();

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_CULL_FACE);
    //glDisable(GL_LIGHTING);

    //SetOrthographicProjection();
    gGraphics.SetProjection(GRAPHICS_ORTHO);

    glLoadIdentity();
    

    if (status==0) { //no transparency
      glColor3f(r,g,b);
      glRectd(x,y,x + w, y + h);
    }
    else{
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      glEnable(GL_BLEND);
      glColor4f(r,g,b,trans);
      glRectd(x,y,x + w, y + h);
      glColor4f(r,g,b,trans + .5);
      //glBegin(GL_LINES);
      //  glVertex2f(x + 25, y + 25);
      //  glVertex2f(x + 100, y + 50);
      //glEnd();
      glDisable(GL_BLEND);
    }

    //ResetPerspectiveProjection();  
    gGraphics.ResetProjection(GRAPHICS_ORTHO);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);
    //glEnable(GL_LIGHTING);

  glPopMatrix();
}

//**************************************
// D R A W 2 D  P A N E L T E X T U R E
// status = 0, not transparent
// status = 1, transparent
//**************************************
void Draw2DPanelTexture(int x,int y, int w, int h,
                        float r, float g, float b, int status)
{
  glPushMatrix();
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_CULL_FACE);
    glDisable(GL_LIGHTING);
    //SetOrthographicProjection();
    gGraphics.SetProjection(GRAPHICS_ORTHO);

    glLoadIdentity();
    
    if (status==0) { //no transparency
      glColor3f(r,g,b);
      glRectd(x,y,x + w, y + h);
    }
    else{
      glEnable(GL_BLEND);
      glBlendFunc(GL_ONE,GL_ONE);
      glColor3f(r,g,b);
      glRectd(x,y,x + w, y + h);
      glDisable(GL_BLEND);
    }

    float th = 1 - (h/w);
    glBegin(GL_QUADS);
    
      glTexCoord2f(0,1);
      glVertex2f(x,y );
      glTexCoord2f(0,th); 
      glVertex2f(x,y + h );
      glTexCoord2f(1,th);
      glVertex2f(x + w, y + h);
      glTexCoord2f(1,1);
      glVertex2f(x + w, y);
    glEnd();

    //ResetPerspectiveProjection();  
    gGraphics.ResetProjection(GRAPHICS_ORTHO);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnable(GL_TEXTURE);
    glEnable(GL_LIGHTING);
  glPopMatrix();
}


                                      
//**************************
// Initializes scene
//**************************
void InitializeGraphics() {
  glClearColor(0,0,0,1);
  glFrontFace(GL_CCW);		// Counter clock-wise polygons face out
  glCullFace(GL_BACK);
  glEnable(GL_CULL_FACE);
  glDepthFunc(GL_LESS);
  glEnable(GL_DEPTH_TEST);
  glEnable ( GL_TEXTURE_2D );
  LoadTextures();
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,
                 gGraphics.near_view, gGraphics.far_view);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutSetCursor(GLUT_CURSOR_NONE); 
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);
  glutWarpPointer(static_cast<int>(gGraphics.window_width/2), 
                  static_cast<int>(gGraphics.window_height/2));
}

//*************************
//Changes size of screen
//*************************
void ResizeWindow(int w1, int h1)
	{

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h1 == 0)
		h1 = 1;
	gGraphics.aspect_ratio = 1.0f * w1 / h1;

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w1, h1);

	// Set the clipping volume
	gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,
                   gGraphics.near_view, gGraphics.far_view);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
}

//*************************************************************************
//*************************************************************************
//*************************************************************************
//*************************************************************************
//      R E N D E R      R E N D E R     R E N D E R     R E N D E R
//*************************************************************************
//*************************************************************************
//*************************************************************************
//*************************************************************************

void RenderScene(void) {
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);

  //allows for setup of program by user in run mode
  if(gGame.GetGameMode() == GAMEMODE_CONFIG){

    //constructs two panels
    glPushMatrix();
      //glClearColor(0,.3,.3,0);         //reinsert to clear background
      //glClear(GL_COLOR_BUFFER_BIT);
      glLoadIdentity();
      Draw2DPanel(100,100,600,400,0,0,.02,1,.01);
//      Draw2DPanel(0,0,static_cast<int>(gGraphics.window_width),
//                  static_cast<int>(gGraphics.window_height),0,0,.02,1,.01);
    glPopMatrix();

    //writes text
    glPushMatrix();
    glClearColor(0,0,0,0);
    glClear(GL_DEPTH_BUFFER_BIT);  //allows text to be written
      gGraphics.SetProjection(GRAPHICS_ORTHO);
      glLoadIdentity();

      switch(gnMouseSelect){
        case 0:
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 1:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 2:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 3:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 4:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          break;

          
      }

      gGraphics.ResetProjection(GRAPHICS_ORTHO);

    glPopMatrix();
  }


//render game play
if(gGame.GetGameMode() == GAMEMODE_PLAY){

  //fps
  gGame.Update(glutGet(GLUT_ELAPSED_TIME));

  //Player movement  
  if (gGraphics.step){
	gFPerson.MoveStep(gGraphics.step);
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);  
  } 
  
  if (gGraphics.sidestep){
    gFPerson.MoveSideStep(gGraphics.sidestep);
   	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
  }
  
  glClearColor(0,0,0,0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


  
  //draws ground reference      
  glBegin(GL_LINES);
    glColor3f(0.0f,1.0f,0.0f);
    for (int i=-25;i<25;i++){
      glVertex3f(i,0,-25);
      glVertex3f(i,0,25);
    }
    for (int j=-25;j<25;j++){
      glVertex3f(-25,0,j);   
      glVertex3f (25,0,j);   
    }
  glEnd();
   
   
    //render all triangles
    glPushMatrix();
      glEnable(GL_TEXTURE_2D);
      glBindTexture ( GL_TEXTURE_2D, gGraphics.texture_objects[3]);
       glBegin(GL_TRIANGLES);
        glColor3f(1,1,1);
          glTexCoord2f(0,1);
          glVertex3f(-2,3,-2);
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,0);
          glVertex3f(2,0,-2 );
      glEnd();
      glDisable(GL_TEXTURE_2D);
    glPopMatrix();

    glPushMatrix();
     gGraphics.SetProjection(GRAPHICS_ORTHO);
      glLoadIdentity();
      glClearDepth(GL_DEPTH_BUFFER_BIT);
      glEnable(GL_DEPTH_TEST);
      glColor3f(0,1,0);
      gGraphics.DrawText2D(100,10,35, "FPS: " + gGame.GetFPSString() );
      gGraphics.ResetProjection(GRAPHICS_ORTHO);

    glPopMatrix();
}
    glutSwapBuffers();
}
//*************************************************************************
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//*************************************************************************


//****************************************************************************
//  Movement functions
//****************************************************************************


//****************************************************************************
//  Input Functions - Keyboard and Mouse
//****************************************************************************

void MousePassiveMotion(int x, int y){
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
    gnMouseSelect = 0;
    if((y > 100) && (y < 125))
      gnMouseSelect = 1;
    if((y > 175) && (y < 200))
      gnMouseSelect = 2;
    if((y > 250) && (y < 275))
      gnMouseSelect = 3;
    if((y > 325) && (y < 350))
      gnMouseSelect = 4;
  }


  //controls game play
  if (gGame.GetGameMode() == GAMEMODE_PLAY){
  int cx = static_cast<int>(gGraphics.window_width/2);
  int cy = static_cast<int>(gGraphics.window_height/2);

  if (x < cx - 5){
    gGraphics.heading -= .05;
    glutWarpPointer(cx,cy);
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (x > cx + 5){
    gGraphics.heading += .05;
    glutWarpPointer(cx,cy);
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (y < cy - 5){
    gGraphics.elevation -= .05;
    glutWarpPointer(cx,cy);
    if (gGraphics.elevation < -PI/2) gGraphics.elevation = -PI/2;
    gFPerson.ChangeElevation(gGraphics.elevation);
  }
  if (y > cy + 5){
    gGraphics.elevation += .05;
    glutWarpPointer(cx,cy);
    if (gGraphics.elevation> PI/2) gGraphics.elevation= PI/2;
    gFPerson.ChangeElevation(gGraphics.elevation);
  }


  glLoadIdentity();
  gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
  }

}
//*******************************************************************
// Movement and button clicks - M O U S E  A C T I V E
//*******************************************************************
void MouseFunction(int button, int state, int x, int y)
{
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
    switch(button){
      case GLUT_LEFT_BUTTON:
        break;
      case GLUT_RIGHT_BUTTON:  
        break;
   }
  }

  if (gGame.GetGameMode() == GAMEMODE_PLAY){
    switch(button){
      case GLUT_LEFT_BUTTON:
        break;
      case GLUT_RIGHT_BUTTON:  
        break;
   }
  }


}

//*****************************************
//Special keys called by glutSpecialFunc()
//*****************************************
void PressExtendedKey(int key, int x, int y) {

  if (gGame.GetGameMode() == GAMEMODE_CONFIG){


  }
  if (gGame.GetGameMode() == GAMEMODE_PLAY){

	switch (key) {
		case GLUT_KEY_LEFT : gGraphics.sidestep=-.2;break;
		case GLUT_KEY_RIGHT : gGraphics.sidestep=.2;break;
		case GLUT_KEY_UP : gGraphics.step = .2;break;
		case GLUT_KEY_DOWN : gGraphics.step = -.2;break;
    case GLUT_KEY_F10: break;
    default:
      gGraphics.step=0;
      gGraphics.sidestep=0;
      break;
	}
  }
}
//******************************************
//Special keys called by glutSpecialUpFunc()
//******************************************
void ReleaseExtendedKey(int key, int x, int y){
 if (gGame.GetGameMode() == GAMEMODE_CONFIG){
 }


  if (gGame.GetGameMode() == GAMEMODE_PLAY){

  switch(key){
		case GLUT_KEY_LEFT : gGraphics.sidestep = 0;break;
		case GLUT_KEY_RIGHT :gGraphics.sidestep = 0;break;
		case GLUT_KEY_UP : gGraphics.step = 0;break;
		case GLUT_KEY_DOWN : gGraphics.step = 0;break;
  }
  }

}

//**********************************************
//Normal key event called by glutKeyboardFunc()
//**********************************************
void PressNormalKey(unsigned char key, int x, int y) {

  //ESC - Exit program
	if (key == 27)
  {
   	exit(0);      
  }

  if((key == 'p')||(key = 'P')){
    if (gGame.GetGameMode() == GAMEMODE_PLAY){
      gGame.SetGameMode(GAMEMODE_CONFIG);
      glutSetCursor(GLUT_CURSOR_LEFT_ARROW);
    }
    else {
      gGame.SetGameMode(GAMEMODE_PLAY);
      glutSetCursor(GLUT_CURSOR_NONE);
    }
  }

  if ((key == 'x')||(key = 'X'))
  {
  
  }

 if (gGame.GetGameMode() == GAMEMODE_CONFIG){
 }
 if (gGame.GetGameMode() == GAMEMODE_PLAY){
 }



}
//****************************************************************************
// Timed Interrupts
//****************************************************************************

//Timer function....called each second
void TimerUpdate(int value){
  //game clock
  
  /*
   gnTimeLeft -= value; //one second countdown timer
  if (gnTimeLeft<1) {
    gnTimeLeft=0;
  }
  */
  //keep calling timer each second
  glutTimerFunc(1000,TimerUpdate,1);
}

/************************************************************************
  main() - This program begins here!  
************************************************************************/
int main(int argc, char **argv)
{

  //setup event logging
  gEventLog.SetFilename("log2.txt");
  gEventLog.LogData("**********************************",0);
  gEventLog.LogData("Start of Program.",0);
  gEventLog.LogData("**********************************",0);
  InitializeVariables();

  //OpenGL/GLUT graphical outputs
  gEventLog.LogData("Initialize OpenGL/GLUT Graphics.",0);
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
  glutInitWindowSize(800,600);
  glutInitWindowPosition(0,0);
  glutCreateWindow(prog.program_name.c_str());
  glutSetCursor(GLUT_CURSOR_NONE);
  glutDisplayFunc(RenderScene);
  glutReshapeFunc(ResizeWindow);
  InitializeGraphics();

  //OpenGL/GLUT inputs - keyboard and mouse
  gEventLog.LogData("Initialize OpenGL/GLUT Keyboard and Mouse.",0);
  glutKeyboardFunc(PressNormalKey);
  glutSpecialFunc(PressExtendedKey);
  glutSpecialUpFunc(ReleaseExtendedKey);     
  glutPassiveMotionFunc(MousePassiveMotion);
  glutMouseFunc(MouseFunction);
    
  //Miscellaneous stuff
  gEventLog.LogData("Initialize Misc. Stuff.",0);
  glutIdleFunc(RenderScene);
  glutTimerFunc(1000,TimerUpdate,1);

  //GLUT Main loop
  gEventLog.LogData("Begin glutMainLoop().",0);
  glutMainLoop();
}


