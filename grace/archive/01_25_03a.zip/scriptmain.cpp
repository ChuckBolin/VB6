/********************************************************************
  Program: Sciptreader  Author: Chuck Bolin (cbolin@dycon.com)
  Description: Reads a ASCII file (*.gam) and extracts info required
  for engine operation.                                       
********************************************************************/
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;
const int SYNTAX_OK = 0;
const int SYNTAX_PARENTHESIS = 1;   //incorrect num of open parenthesis
const int SYNTAX_SEMICOLON = 2;     //missing semicolon
const int SYNTAX_OPEN_PARENTHESIS = 3; 
const int SYNTAX_CLOSED_PARENTHESIS = 4;
const int SYNTAX_QUOTE = 5;
const int SYNTAX_UNKNOWN = 99;      //unknown error

/****************************************************
 CheckStatus( )
 Verifies correct number of { },( ) and ;
****************************************************/
int CheckSyntax(string linein){
  int status = SYNTAX_OK; //okay
  int open_par = 0;       //number of open parenthesis
  int closed_par = 0;      //number of closed parenthesis
  int semicolon = 0; 
  int left_brace = 0;
  int right_brace = 0;
  int quote = 0;

  if (linein.length() >0 ) {

  if (linein.substr(0,2)=="//") { //comment line...all is okay
    status = SYNTAX_OK;
  }
  else{
  
    //parenthesis error
    for(int i=0;i< linein.length();i++){  //check parenthesis
      if (linein.substr(i,1)=="(") 
        open_par += 1;
      if (linein.substr(i,1)==")")
        closed_par += 1;
      if (linein.substr(i,1)==";")
        semicolon += 1;
      if (linein.substr(i,1)=="{")
        left_brace += 1;
      if (linein.substr(i,1)=="}")
        right_brace += 1;
      if (linein.substr(i,1)=="\"")
        quote += 1;  
    } 


    //if (open_par > 0) cout << "(: " << open_par << endl;  
    ///if (closed_par > 0) cout << "): " << closed_par << endl;  
    //if (semicolon > 0) cout << ";: " << semicolon << endl;  
    //if (left_brace > 0) cout << "{: " << left_brace << endl;  
    //if (right_brace > 0) cout << "}: " << right_brace << endl;  
    
    if ((left_brace < 1) && (right_brace < 1)&& (semicolon < 1 ))
      status = SYNTAX_SEMICOLON;
    if (((left_brace > 0 ) || (right_brace > 0)) && (status == SYNTAX_SEMICOLON))
      status = SYNTAX_OK;  
    if (open_par != closed_par ){
      if (open_par > closed_par)
        status = SYNTAX_CLOSED_PARENTHESIS;
      else
        status = SYNTAX_OPEN_PARENTHESIS;
    }  
    if ((quote ==1 ) || (quote == 3) || (quote == 5) || (quote == 7))
      status = SYNTAX_QUOTE;
    
    /*
    if (open_par != closed_par)  {
      status = SYNTAX_PARENTHESIS;  // num of '(' doesn't match num of ')'
    }  
    
    if ((semicolon == 0) && (status = SYNTAX_OK))  {
      status = SYNTAX_SEMICOLON;
    }     
    */
  }
  }
  return status;     
}


/****************************************************
 CleanUp( )
removes spacing and converts all to lower case
****************************************************/
string CleanUp(string linein){
  string lineout;
  string lineoutlower;
  int it;
  
                                                    
  if (linein.substr(0,2)!="//"){    //exclude comments from cleansing

    //let's go through string, one character at a time
    for(it = 0; it < linein.length();it++){
      if(linein.substr(it,1)!= " ")
        lineout += linein.substr(it,1);
    }
    
    //convert string to lower case (doesn't affect comment
    char *buf = new char[lineout.length()]; //create temp buffer
    lineout.copy(buf, lineout.length());    //copy string to buffer
    for (int i=0; i<lineout.length();i++){
      buf[i] = tolower(buf[i]);             //convert to lowercase 1 at a time
    }  
    string lineoutlower(buf, lineout.length()); //transfer buffer to string
    delete buf;
    lineout = lineoutlower;
  }
  else{
    lineout += linein;             //add comment unchanged
  }
  
  return lineout;
}


/********************************************************************
 main( )
********************************************************************/
int main(int argc, char *argv[])
{

  ifstream in;
  ofstream out("temp.fil",ios::out);
  string line;
  string lineout;
  streamsize count;
  int num_errors = 0;
  int status = 0;
  int linecount = 0;
  char c[255];
  //string filename = "script1.gam";
  //in.open(filename.c_str());
  in.open(argv[1]);    //filename passed as command line argument
  if(!in){
    exit(0);
  }

  cout << "*********************************" << endl;
  cout << "Grace Engine v0.1 Sript Processor" << endl;
  cout << "*********************************" << endl;
  
  while (!in.eof()){  //get one line at a time from script file
    in.getline(c, count);
    line = c;
    lineout= CleanUp(line);   //clean up line
    linecount += 1;
    cout << linecount << ": " << line << endl;
    if(linecount==10) system("pause");
    if(linecount==20) exit(0);
    //cout << "Clean: " + lineout << endl;   
    //cout << "Status: " << CheckSyntax(lineout) << endl;
    /*
    status = CheckSyntax(lineout);
    if (status > SYNTAX_OK) num_errors += 1;
    cout << linecount << ": " << lineout << endl;    

    switch (status){  //check for syntax errors
      case SYNTAX_OK:
        out << lineout << endl;
        break;
      case SYNTAX_PARENTHESIS:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Parenthesis...open or closed...doesn't add up!" << endl<< endl;
        break;
      case SYNTAX_OPEN_PARENTHESIS:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Open parenthesis is missing!" << endl<< endl;
        break;
      case SYNTAX_CLOSED_PARENTHESIS:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Closed parenthesis is missing!" << endl<< endl;
        break;
      case SYNTAX_SEMICOLON:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Missing semicolon!" << endl<< endl;
        break;
      case SYNTAX_UNKNOWN:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Unknown error!" << endl<< endl;
        break;
      case SYNTAX_QUOTE:
        cout << "        ^ ^ ^ " << endl;
        cout << "       Odd number of quotation marks.!" << endl<< endl;
        break;
      
    } 
    */
       
  }
  
  cout << endl;
  cout << "*********************************" << endl;
  cout << num_errors << " errors was/were detected!" << endl;
  cout << "*********************************" << endl;
  cout << endl;

  system("pause");
  return 0;
}
