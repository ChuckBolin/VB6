/*********************************************************************
 PROGRAM - Written by Chuck Bolin
 This program uses the accompanying Grace Engine v0.1
*********************************************************************/

//Includes files
#define GLUT_DISABLE_ATEXIT_HACK
#include <gl\gl.h>
#include <gl\glut.h>
#include <gl\glu.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <vector>
#include <ctime>
#include "eventlog.h"
#include "program.h"
#include "fperson.h"
#include "graphics.h"
#include "bitmap.h"
#include "mymath.h"
#include "gameobj.h"
#include "engine.h"
#include "input.h"

using namespace std;

//****************************************************************************
//  Function prototypes
//****************************************************************************
 void LoadFont(void);

//****************************************************************************
//  Global Variables and constants
//****************************************************************************
PROGRAMINFO prog;     //stores program details..name, version, email, etc.



//****************************************************************************
//  Initialization
//****************************************************************************


//************************************
//Initialize objects and variables
//************************************
void InitializeVariables()
{
  //initialize graphics
  gGraphics.near_view = .01;
  gGraphics.far_view = 200;
  gGraphics.view_angle = 45;
  
  //initialize first person
  gFPerson.Initialize(0,1.75,0,0,0,-1,0,1,0);
   
  //program specific information
  prog.version_number = gProgram.SetVersion("0.1");
  prog.program_name = gProgram.SetProgramName("Grace Engine");
  prog.program_description = gProgram.SetProgramDescription("This is a basic program.");
  prog.revision_date = gProgram.SetRevisionDate("01.16.03");
  prog.programmer_name = gProgram.SetProgrammerName("Chuck Bolin");
  prog.programmer_email = gProgram.SetProgrammerEmail("cbolin@dycon.com");
  prog.programmer_URL = gProgram.SetProgrammerURL("http://www.clg-net.com");
  prog.help_file = gProgram.SetHelpFile("help.htm");
  
  //datalog info
  gEventLog.LogData("Version: " + prog.version_number, 0);
  gEventLog.LogData("Program: " + prog.program_name,0);
  gEventLog.LogData("Description: " + prog.program_description,0);
  gEventLog.LogData("Revision Date: " + prog.revision_date,0);
  gEventLog.LogData("Programmer: " + prog.programmer_name,0);
  gEventLog.LogData("Email: " + prog.programmer_email,0);
  gEventLog.LogData("URL: " + prog.programmer_URL,0);
  gEventLog.LogData("Help file: " + prog.help_file,0);

  //load font info
  int ret = gGraphics.CreateFont(2);
  if (ret == 0){
    gEventLog.LogData("Font bitmap not found!", 0);
  }
  gGraphics.LoadFont();
  gEventLog.LogData("Font loaded",0);

  //game program specifics
  gGame.SetTimeFactor(1.0);
  gGame.SetGameMode(GAMEMODE_PLAY);
}

string FloatToString(float n){
  char buffer[50];
  ostrstream Str(buffer, 50);
  Str << n << ends;
  string mynum(Str.str());
  return mynum;
}

//****************************************************************************
//  Graphics
//****************************************************************************

//**************************
// Initializes scene
//**************************
void InitializeGraphics() {
  glClearColor(0,0,0,1);
  glFrontFace(GL_CCW);		// Counter clock-wise polygons face out
  glCullFace(GL_BACK);
  glEnable(GL_CULL_FACE);
  glDepthFunc(GL_LESS);
  glEnable(GL_DEPTH_TEST);
  glEnable ( GL_TEXTURE_2D );
  LoadTextures();
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,
                 gGraphics.near_view, gGraphics.far_view);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutSetCursor(GLUT_CURSOR_NONE); 
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);
  glutWarpPointer(static_cast<int>(gGraphics.window_width/2), 
                  static_cast<int>(gGraphics.window_height/2));
  gGame.EnableRender();
}

//*************************
//Changes size of screen
//*************************
void ResizeWindow(int w1, int h1)
	{

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h1 == 0)
		h1 = 1;
	gGraphics.aspect_ratio = 1.0f * w1 / h1;

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w1, h1);

	// Set the clipping volume
	gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,
                   gGraphics.near_view, gGraphics.far_view);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
}

//*************************************************************************
//*************************************************************************
//*************************************************************************
//*************************************************************************
//      R E N D E R      R E N D E R     R E N D E R     R E N D E R
//*************************************************************************
//*************************************************************************
//*************************************************************************
//*************************************************************************

void RenderScene(void) {
 
  if(gGame.GetRenderStatus()==true){
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);

  //allows for setup of program by user in run mode
  if(gGame.GetGameMode() == GAMEMODE_CONFIG){

    //constructs two panels
    glPushMatrix();
      //glClearColor(0,.3,.3,0);         //reinsert to clear background
      //glClear(GL_COLOR_BUFFER_BIT);
      glLoadIdentity();
      gGraphics.Draw2DPanel(100,100,600,400,0,0,.02,1,.01);
      gGraphics.Draw2DPanel(0,0,static_cast<int>(gGraphics.window_width),
                  static_cast<int>(gGraphics.window_height),0,0,.02,1,.01);
    glPopMatrix();

    //writes text
    glPushMatrix();
    glClearColor(0,0,0,0);
    glClear(GL_DEPTH_BUFFER_BIT);  //allows text to be written
      gGraphics.SetProjection(GRAPHICS_ORTHO);
      glLoadIdentity();

      switch(gInput.mouse_select){
        case 0:
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 1:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 2:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 3:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          break;
        case 4:
          glColor3f(0,1,0);
          gGraphics.DrawText2D(110,325,25, "CONTINUE...");
          glColor3f(1,1,1);
          gGraphics.DrawText2D(110,100,25, "OPTION1");
          gGraphics.DrawText2D(110,175,25, "OPTION2");
          gGraphics.DrawText2D(110,250,25, "OPTION3");
          break;
      }
      gGraphics.ResetProjection(GRAPHICS_ORTHO);
    glPopMatrix();
}

//render game play
if(gGame.GetGameMode() == GAMEMODE_PLAY){

  //fps
  gGame.Update(glutGet(GLUT_ELAPSED_TIME));

  //Player movement  
  if (gGraphics.step){
	gFPerson.MoveStep(gGraphics.step);
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);  
  } 
  
  if (gGraphics.sidestep){
    gFPerson.MoveSideStep(gGraphics.sidestep);
   	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
  }
  
  glClearColor(0,0,0,0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


  
  //draws ground reference      
  glBegin(GL_LINES);
    glColor3f(0.0f,1.0f,0.0f);
    for (int i=-25;i<25;i++){
      glVertex3f(i,0,-25);
      glVertex3f(i,0,25);
    }
    for (int j=-25;j<25;j++){
      glVertex3f(-25,0,j);   
      glVertex3f (25,0,j);   
    }
  glEnd();
   
  
    //render all triangles
    glPushMatrix();
      glEnable(GL_TEXTURE_2D);
      glBindTexture ( GL_TEXTURE_2D, gGraphics.texture_objects[3]);
       glBegin(GL_TRIANGLES);
        glColor3f(1,1,1);
          glTexCoord2f(0,1);
          glVertex3f(-2,3,-2);
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,0);
          glVertex3f(2,0,-2 );
      glEnd();
      glDisable(GL_TEXTURE_2D);
    glPopMatrix();
  
   
    //display info           
    glPushMatrix();
     gGraphics.SetProjection(GRAPHICS_ORTHO);
      glLoadIdentity();
      glClearDepth(GL_DEPTH_BUFFER_BIT);
      glEnable(GL_DEPTH_TEST);
      glColor3f(0,1,0);
      gGraphics.DrawText2D(100,10,35, "FPS: " + gGame.GetFPSString() );
      gGraphics.ResetProjection(GRAPHICS_ORTHO);

    glPopMatrix();
    
}
   gGame.DisableRender();
    glutSwapBuffers();
}
   
 
   //render if true  
}
//*************************************************************************
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
//*************************************************************************


//****************************************************************************
//  Input Functions - Keyboard and Mouse
//****************************************************************************

void MousePassiveMotion(int x, int y){
  PROGRAMINPUT input;
  input.event = INPUT_PASSIVE_MOUSE;
  input.x = x;
  input.y = y;
  gInput.ProcessInput(input);
}
//*******************************************************************
// Movement and button clicks - M O U S E  A C T I V E
//*******************************************************************
void MouseFunction(int button, int state, int x, int y)
{
  PROGRAMINPUT input;
  input.event = INPUT_ACTIVE_MOUSE;
  input.button = button;
  input.state = state;
  input.x = x;
  input.y = y;
  gInput.ProcessInput(input);
}

//*****************************************
//Special keys called by glutSpecialFunc()
//*****************************************
void PressExtendedKey(int key, int x, int y) {
  PROGRAMINPUT input;
  input.event = INPUT_EXTENDED_KEY_DOWN;
  input.key = key;
  input.x = x;
  input.y = y;
  gInput.ProcessInput(input);
}

//******************************************
//Special keys called by glutSpecialUpFunc()
//******************************************
void ReleaseExtendedKey(int key, int x, int y){
  PROGRAMINPUT input;
  input.event = INPUT_EXTENDED_KEY_UP;
  input.key = key;
  input.x = x;
  input.y = y;
  gInput.ProcessInput(input);
}

//**********************************************
//Normal key event called by glutKeyboardFunc()
//**********************************************
void PressNormalKey(unsigned char key, int x, int y) {
  PROGRAMINPUT input;
  input.event = INPUT_NORMAL_KEY_DOWN;
  input.uckey = key;
  input.x = x;
  input.y = y;
  gInput.ProcessInput(input);
}

//****************************************************************************
// Timed Interrupts
//****************************************************************************

//Timer function....called each second
void TimerUpdate(int value){

  gGame.EnableRender();
  //gGame.Update(glutGet(GLUT_ELAPSED_TIME));
  //game clock
  
  /*
   gnTimeLeft -= value; //one second countdown timer
  if (gnTimeLeft<1) {
    gnTimeLeft=0;
  }
  */
  //keep calling timer each second
  glutTimerFunc(5, TimerUpdate,1);
}

/************************************************************************
  main() - This program begins here!  
************************************************************************/
int main(int argc, char **argv)
{

  cout << "Starting application...." << endl;
  cout << GLUT_KEY_DOWN << endl;
  
  //system ("pause");

  //setup event logging
  gEventLog.SetFilename("log2.txt");
  gEventLog.LogData("**********************************",0);
  gEventLog.LogData("Start of Program.",0);
  gEventLog.LogData("**********************************",0);
  InitializeVariables();

  //OpenGL/GLUT graphical outputs
  gEventLog.LogData("Initialize OpenGL/GLUT Graphics.",0);
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
  glutInitWindowSize(800,600);
  glutInitWindowPosition(0,0);
  glutCreateWindow(prog.program_name.c_str());
  glutSetCursor(GLUT_CURSOR_NONE);
  glutDisplayFunc(RenderScene);
  glutReshapeFunc(ResizeWindow);
  InitializeGraphics();

  //OpenGL/GLUT inputs - keyboard and mouse
  gEventLog.LogData("Initialize OpenGL/GLUT Keyboard and Mouse.",0);
  glutKeyboardFunc(PressNormalKey);
  glutSpecialFunc(PressExtendedKey);
  glutSpecialUpFunc(ReleaseExtendedKey);     
  glutPassiveMotionFunc(MousePassiveMotion);
  glutMouseFunc(MouseFunction);
    
  //Miscellaneous stuff
  gEventLog.LogData("Initialize Misc. Stuff.",0);
  glutIdleFunc(RenderScene);
  glutTimerFunc(33,TimerUpdate,1);

  //GLUT Main loop
  gEventLog.LogData("Begin glutMainLoop().",0);
  glutMainLoop();
}


