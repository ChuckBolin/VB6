#include <cstdlib>
#include <iostream>
#include <string>
#include "eventlog.h"

int main()
{
  gEventLog.SetFilename("log3.txt");
  gEventLog.LogData("Testing this program...",0);
  system("pause");
  exit(0);
}
