/*******************************************************************************
 INPUT.CPP
 Programmer: Chuck Bolin, 2003
 Purpose:    All input: mouse, keyboard comes here for processing.
*******************************************************************************/

//Include files
#include "input.h"
#include "fperson.h"



void CInput::ProcessInput (PROGRAMINPUT input){
  switch(input.event){
    case INPUT_PASSIVE_MOUSE:
      PassiveMouse(input);
      break;
    case INPUT_ACTIVE_MOUSE:
      ActiveMouse(input);
      break;
    case INPUT_EXTENDED_KEY_DOWN:
      ExtendedKeyDown(input);
      break;
    case INPUT_EXTENDED_KEY_UP:
      ExtendedKeyUp(input);
      break;
    case INPUT_NORMAL_KEY_DOWN:
      NormalKeyDown(input);
      break;
    case INPUT_TIMER:
      break;
  }
}

void CInput::PassiveMouse(PROGRAMINPUT input){
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
    gInput.mouse_select = 0;
    if((input.y > 100) && (input.y < 125))
      gInput.mouse_select= 1;
    if((input.y > 175) && (input.y < 200))
      gInput.mouse_select = 2;
    if((input.y > 250) && (input.y < 275))
      gInput.mouse_select = 3;
    if((input.y > 325) && (input.y < 350))
      gInput.mouse_select = 4;
  }

  //controls game play
  if (gGame.GetGameMode() == GAMEMODE_PLAY){
  int cx = static_cast<int>(gGraphics.window_width/2);
  int cy = static_cast<int>(gGraphics.window_height/2);

  if (input.x < cx - 5){
    gGraphics.heading -= .05;
    glutWarpPointer(cx,cy);
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (input.x > cx + 5){
    gGraphics.heading += .05;
    glutWarpPointer(cx,cy);
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (input.y < cy - 5){
    gGraphics.elevation -= .05;
    glutWarpPointer(cx,cy);
    if (gGraphics.elevation < -PI/2) gGraphics.elevation = -PI/2;
    gFPerson.ChangeElevation(gGraphics.elevation);
  }
  if (input.y > cy + 5){
    gGraphics.elevation += .05;
    glutWarpPointer(cx,cy);
    if (gGraphics.elevation> PI/2) gGraphics.elevation= PI/2;
    gFPerson.ChangeElevation(gGraphics.elevation);
  }


  glLoadIdentity();
  gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
  }


}

void CInput::ActiveMouse(PROGRAMINPUT input){

  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
    switch(input.button){
      case GLUT_LEFT_BUTTON:
        break;
      case GLUT_RIGHT_BUTTON:  
        break;
   }
  }

  if (gGame.GetGameMode() == GAMEMODE_PLAY){
    switch(input.button){
      case GLUT_LEFT_BUTTON:
        break;
      case GLUT_RIGHT_BUTTON:  
        break;
   }
  }
}

void CInput::ExtendedKeyDown(PROGRAMINPUT input){
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){


  }
  if (gGame.GetGameMode() == GAMEMODE_PLAY){

	  switch (input.key) {
		  case GLUT_KEY_LEFT : gGraphics.sidestep=-.2;break;
		  case GLUT_KEY_RIGHT : gGraphics.sidestep=.2;break;
		  case GLUT_KEY_UP : gGraphics.step = .2;break;
		  case GLUT_KEY_DOWN : gGraphics.step = -.2;break;
      case GLUT_KEY_F10: break;
      default:
        gGraphics.step=0;
        gGraphics.sidestep=0;
        break;
	  }
  }
}

void CInput::ExtendedKeyUp(PROGRAMINPUT input){
 
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
 
  }
 
  if (gGame.GetGameMode() == GAMEMODE_PLAY){

    switch(input.key){
	    case GLUT_KEY_LEFT : gGraphics.sidestep = 0;break;
		  case GLUT_KEY_RIGHT :gGraphics.sidestep = 0;break;
		  case GLUT_KEY_UP : gGraphics.step = 0;break;
		  case GLUT_KEY_DOWN : gGraphics.step = 0;break;
    }
  }
}

void CInput::Timer(PROGRAMINPUT input){

}

//Normal key is pressed down
void CInput::NormalKeyDown(PROGRAMINPUT input){

  if (input.uckey == 32){   //toggle modes
    if (gGame.GetGameMode() == GAMEMODE_CONFIG)
        gGame.SetGameMode(GAMEMODE_PLAY);
    else
        gGame.SetGameMode(GAMEMODE_CONFIG);
  }

  //ALT + S...doesn't work
  if (((input.key == 's') || (input.key == 'S')) && 
                          (glutGetModifiers && GLUT_ACTIVE_ALT)){
    exit(0);  
  }
  
  if (input.uckey == 27){ //quit program
    exit(0);
  }

}


