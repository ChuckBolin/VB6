/*******************************************************************************
 engine.h
 Programmer: Chuck Bolin, 2003
 Purpose:  Miscellaneous engine stuff
*******************************************************************************/
#ifndef _ENGINE_ENGINE_H
#define _ENGINE_ENGINE_H

//bitmap font structure for indivual characters
typedef struct
{
  int ascii;           //ascii character of font
  char chr;            //actual character
  VERTEX2D a,b,c,d;    //corners starting at top-left going ccw
} MYFONT;

#endif _ENGINE_ENGINE_H


