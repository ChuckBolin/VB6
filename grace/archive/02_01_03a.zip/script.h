/*******************************************************************************
 SCRIPT class
 Programmer: Chuck Bolin, 2003
 Purpose:  Allows for data logging of events (strings)
*******************************************************************************/
#ifndef _ENGINE_SCRIPT_H
#define _ENGINE_SCRIPT_H

//include files
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <strstream>

// Class Definition
class CScript
{
  public:

 


  enum SCRIPT_CONSTANTS
  {
    SYNTAX_OK =0,
    SYNTAX_PARENTHESIS ,   //incorrect num of open parenthesis
    SYNTAX_SEMICOLON  ,     //missing semicolon
    SYNTAX_OPEN_PARENTHESIS , 
    SYNTAX_CLOSED_PARENTHESIS ,
    SYNTAX_QUOTE ,
    SYNTAX_UNKNOWN =99      //unknown error
  };
  
  static CScript& Instance()
  {
    static CScript instance;
    return instance;  
  }
  
  //member functions
  int CheckSyntax(string);
  string CleanUp(string);
  void DisplayResults(string);
  int GetNumErrors(void);
  void Push(string);
  
  private:
  //constructor
  CScript(){}
  
  //destructor
  ~CScript(){}   
  
  int number_errors;
  vector<string> script;

};
#define gScript CScript::Instance()
#endif _ENGINE_SCRIPT_H


/***********************************************************************
  Sample usage:
  
  //read command line arg
  string scriptfile;
  scriptfile = argv[1];
  gScript.DisplayResults(scriptfile);
  . . .
  string lineout= gScript.CleanUp(line);  //clean up line..spaces, lower case
  status = gScript.CheckSyntax(lineout);  //returns integer indicating error

***********************************************************************/
