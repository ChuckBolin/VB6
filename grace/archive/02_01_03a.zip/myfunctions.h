/*******************************************************************************
 MYFUNCTIONS 
 Programmer: Chuck Bolin, 2003
 Purpose:  Collection of functions that correspond to script
*******************************************************************************/
#ifndef _ENGINE_MYFUNCTIONS_H
#define _ENGINE_MYFUNCTIONS_H

//include files
#include <iostream>

enum MYFUNCTION_CONSTANTS
{
  MYFUNCTION_MOVELEFT = 0,
  MYFUNCTION_MOVERIGHT = 1
};

void LoadFunctionTable(void);  
void FuncMoveLeft(void);
void FuncMoveRight(void);

#endif _ENGINE_MYFUNCTIONS_H

