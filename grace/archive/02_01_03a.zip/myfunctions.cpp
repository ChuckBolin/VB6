/****************************************************************************
  MYFUNCTIONS.CPP - Stores all functions required by Engine to process
  Script file.
****************************************************************************/  
#include "myfunctions.h"

typedef void GenericFunction(void);      //type of function
GenericFunction *gpFunctionList[200]; //array of pointers to function




void LoadFunctionTable(){        //load table
  gpFunctionList[MYFUNCTION_MOVELEFT] = FuncMoveLeft;
  gpFunctionList[MYFUNCTION_MOVERIGHT] = FuncMoveRight;
}

void FuncMoveLeft(){                    
  cout << "Moving to the left..." << endl;

}

void FuncMoveRight(){                   
  cout << "Moving to the right..." << endl;

}
