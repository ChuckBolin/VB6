/********************************************************************
  Program: Sciptreader  Author: Chuck Bolin (cbolin@dycon.com)
  Description: Reads a ASCII file (*.gam) and extracts info required
  for engine operation.                                       
********************************************************************/
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include "script.h"
#include "myfunctions.h"

using namespace std;

typedef void GenericFunction(void);      //type of function
extern GenericFunction *gpFunctionList[200]; //array of pointers to function


int main(int argc, char *argv[])
{
  LoadFunctionTable();               //assign pointers to functions
  string scriptfile;
  
  if (argc >1 ){
    scriptfile = argv[1];
    system("pause");
    gScript.DisplayResults(scriptfile);
  
    if (gScript.GetNumErrors() > 0){
      cout << "Errors reading script file. Aborting program..." << endl;
      cout << "Press any key to continue." << endl;
      system("pause");
      exit(0);
    }
  }
  
  cout << "Begin" << endl;
  gpFunctionList[MYFUNCTION_MOVELEFT]();
  gpFunctionList[MYFUNCTION_MOVERIGHT]();
  cout << "End" << endl;
  system("pause");                   //necessary for Dev-C++
  return 0;
}


  /*
#include <fstream>
#include <string>
#include "script.h"


  string scriptfile;
  scriptfile = argv[1];
  gScript.DisplayResults(scriptfile);
  */

