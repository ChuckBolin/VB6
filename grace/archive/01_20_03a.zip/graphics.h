/*******************************************************************************
 GRAPHICS class
 Programmer: Chuck Bolin, 2003
 Purpose:  Info pertaining to game graphics.
*******************************************************************************/
#ifndef _ENGINE_GRAPHICS_H
#define _ENGINE_GRAPHICS_H

//include files
 
#include <string>
#include <fstream>
#include <ctime>
#include <iostream>
#include <strstream>     
#include <gl\gl.h>
#include <gl\glut.h>   

//required for reading bitmap files
typedef struct {
    unsigned short type;
    unsigned long size;
    unsigned short reserved1;
    unsigned short reserved2;
    unsigned long offset;  
} BITMAPFILEHEADER;
  
typedef struct {
    unsigned long size;
    long width;
    long height;
    unsigned short planes;
    unsigned short bitcount;
    unsigned long compression;
    unsigned long sizeimage;
    long xpelspermeter;
    long ypelspermeter;
    unsigned long clrused;
    unsigned long clrimportant;
} BITMAPINFOHEADER;

// Class Definition
class CGraphics
{
  public:
    float window_width, window_height;
    float aspect_ratio;
    float near_view, far_view, view_angle;
    float step, sidestep, heading, elevation;
    int max_textures;
    GLuint texture_objects[20];
    
  static CGraphics& Instance()
  {
    static CGraphics instance;
    return instance;  
  }
  
  //member functions

  private:

  //constructor
  CGraphics(){}
  
  //destructor
  ~CGraphics(){}   
  
};
#define gGraphics CGraphics::Instance()
#endif _ENGINE_GRAPHICS_H


/***********************************************************************
  Sample usage:

***********************************************************************/
