/*********************************************************************
 PROGRAM - Written by Chuck Bolin
 This program uses the accompanying Engine v0.1

*********************************************************************/

//Includes files
//#define GLUT_DISABLE_ATEXIT_HACK
#include <gl\gl.h>
#include <gl\glut.h>
#include <gl\glu.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <vector>
#include <ctime>
#include "3dstuff.h"
#include "eventlog.h"
#include "program.h"
#include "fperson.h"
#include "graphics.h"


using namespace std;

//****************************************************************************
//  Function prototypes
//****************************************************************************


//****************************************************************************
//  Global Variables and constants
//****************************************************************************

//window and aspect stuff
//float gfRatio;               //holds aspect ratio of screen
//float gfNearView, gfFarView; //used to define near/far for gluPerspective
//float gfViewAngle;

//texture stuff
//int gnMaxTextures = 20;
//GLuint texture_objects[20];  //stores textures
PROGRAMINFO prog;     //stores program details..name, version, email, etc.



//****************************************************************************
//  Initialization
//****************************************************************************


//************************************
//Initialize objects and variables
//************************************
void InitializeVariables()
{
  gGraphics.near_view = .01;
  gGraphics.far_view = 200;
  gGraphics.view_angle = 45;
  
  //initialize first person
  gFPerson.Initialize(0,1.75,0,0,0,-1,0,1,0);
   
  //program specific information
  prog.version_number = gProgram.SetVersion("0.1");
  prog.program_name = gProgram.SetProgramName("Grace Engine");
  prog.program_description = gProgram.SetProgramDescription("This is a basic program.");
  prog.revision_date = gProgram.SetRevisionDate("01.16.03");
  prog.programmer_name = gProgram.SetProgrammerName("Chuck Bolin");
  prog.programmer_email = gProgram.SetProgrammerEmail("cbolin@dycon.com");
  prog.programmer_URL = gProgram.SetProgrammerURL("http://www.clg-net.com");
  prog.help_file = gProgram.SetHelpFile("help.htm");
  
  //datalog info
  gEventLog.LogData("Version: " + prog.version_number, 0);
  gEventLog.LogData("Program: " + prog.program_name,0);
  gEventLog.LogData("Description: " + prog.program_description,0);
  gEventLog.LogData("Revision Date: " + prog.revision_date,0);
  gEventLog.LogData("Programmer: " + prog.programmer_name,0);
  gEventLog.LogData("Email: " + prog.programmer_email,0);
  gEventLog.LogData("URL: " + prog.programmer_URL,0);
  gEventLog.LogData("Help file: " + prog.help_file,0);
   
}

//****************************************************************************
//  Graphics
//****************************************************************************

                                      
//**************************
// Initializes scene
//**************************
void InitializeGraphics() {
  glClearColor(0,0,0,1);
	glFrontFace(GL_CCW);		// Counter clock-wise polygons face out
  glCullFace(GL_BACK);
  glEnable(GL_CULL_FACE);
  glDepthFunc(GL_LESS);
  glEnable(GL_DEPTH_TEST);
  glEnable ( GL_TEXTURE_2D );
  LoadTextures();
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
	gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,gGraphics.near_view, gGraphics.far_view);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutSetCursor(GLUT_CURSOR_NONE); 
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);
  glutWarpPointer(static_cast<int>(gGraphics.window_width/2), 
                  static_cast<int>(gGraphics.window_height/2));
}

//*************************
//Changes size of screen
//*************************
void ResizeWindow(int w1, int h1)
	{

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h1 == 0)
		h1 = 1;
	gGraphics.aspect_ratio = 1.0f * w1 / h1;

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	// Set the viewport to be the entire window
  glViewport(0, 0, w1, h1);

	// Set the clipping volume
	gluPerspective(gGraphics.view_angle,gGraphics.aspect_ratio,gGraphics.near_view, gGraphics.far_view);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
}

//*************************************************************************
//Draws everything to screen
//*************************************************************************
void RenderScene(void) {
  gGraphics.window_width = glutGet(GLUT_WINDOW_WIDTH);
  gGraphics.window_height = glutGet(GLUT_WINDOW_HEIGHT);

  //Player movement  
    
	if (gGraphics.step){
		gFPerson.MoveStep(gGraphics.step);
	  glLoadIdentity();
	  gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);  
  } 
  
  if (gGraphics.sidestep){
    gFPerson.MoveSideStep(gGraphics.sidestep);
   	glLoadIdentity();
	  gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
	}
  
	glClearColor(0,0,0,0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  //draws ground reference      
  glBegin(GL_LINES);
    glColor3f(0.0f,1.0f,0.0f);
    for (int i=-25;i<25;i++){
      glVertex3f(i,0,-25);
      glVertex3f(i,0,25);
    }
    for (int j=-25;j<25;j++){
      glVertex3f(-25,0,j);   
      glVertex3f (25,0,j);   
    }
	glEnd();
   
   
    //render all triangles
    glPushMatrix();
      glEnable(GL_TEXTURE_2D);
      glBindTexture ( GL_TEXTURE_2D, gGraphics.texture_objects[1]);
      glBegin(GL_TRIANGLES);
        glColor3f(1,1,1);
          glTexCoord2f(0,1);
          glVertex3f(-2,3,-2);
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          
          glTexCoord2f(1,1);
          glVertex3f(2,3,-2 );
          glTexCoord2f(0,0); 
          glVertex3f(-2,0,-2 );
          glTexCoord2f(1,0);
          glVertex3f(2,0,-2 );
      glEnd();
      glDisable(GL_TEXTURE_2D);
    glPopMatrix();
    
    glutSwapBuffers();
}

//****************************************************************************
//  Movement functions
//****************************************************************************


//****************************************************************************
//  Input Functions - Keyboard and Mouse
//****************************************************************************

void MousePassiveMotion(int x, int y){

  int cx = static_cast<int>(gGraphics.window_width/2);
  int cy = static_cast<int>(gGraphics.window_height/2);
  if (x < cx - 5){
    gGraphics.heading -= .05;
    glutWarpPointer(cx,cy);  
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (x > cx + 5){
    gGraphics.heading += .05;
    glutWarpPointer(cx,cy);  
    gFPerson.ChangeHeading(gGraphics.heading);
  }
  if (y < cy - 5){
    gGraphics.elevation -= .05;
    if (gGraphics.elevation < -PI/2) gGraphics.elevation = -PI/2;
    glutWarpPointer(cx,cy);  
    gFPerson.ChangeElevation(gGraphics.elevation);
  }
  if (y > cy + 5){
    gGraphics.elevation += .05;
    if (gGraphics.elevation> PI/2) gGraphics.elevation= PI/2;
    glutWarpPointer(cx,cy);  
    gFPerson.ChangeElevation(gGraphics.elevation);
  }
  
	glLoadIdentity();
	gluLookAt(gFPerson.x, gFPerson.y,gFPerson.z, gFPerson.x + gFPerson.lx,
            gFPerson.y + gFPerson.ly,gFPerson.z + gFPerson.lz,
			      gFPerson.up_x, gFPerson.up_y, gFPerson.up_z);
}
//*******************************************************************
// Movement and button clicks - M O U S E  A C T I V E
//*******************************************************************
void MouseFunction(int button, int state, int x, int y)
{
    switch(button){
      case GLUT_LEFT_BUTTON:
        break;
      case GLUT_RIGHT_BUTTON:  
        break;
   }
}

//*****************************************
//Special keys called by glutSpecialFunc()
//*****************************************
void PressExtendedKey(int key, int x, int y) {

	switch (key) {
		case GLUT_KEY_LEFT : gGraphics.sidestep=-.2;break;
		case GLUT_KEY_RIGHT : gGraphics.sidestep=.2;break;
		case GLUT_KEY_UP : gGraphics.step = .2;break;
		case GLUT_KEY_DOWN : gGraphics.step = -.2;break;
    case GLUT_KEY_F10: break;
    default:
      gGraphics.step=0;
      gGraphics.sidestep=0;
      break;
	}
}

void ReleaseExtendedKey(int key, int x, int y){
  switch(key){
		case GLUT_KEY_LEFT : gGraphics.sidestep = 0;break;
		case GLUT_KEY_RIGHT :gGraphics.sidestep = 0;break;
		case GLUT_KEY_UP : gGraphics.step = 0;break;
		case GLUT_KEY_DOWN : gGraphics.step = 0;break;
  }
}

//**********************************************
//Normal key event called by glutKeyboardFunc()
//**********************************************
void PressNormalKey(unsigned char key, int x, int y) {

  //ESC - Exit program
	if (key == 27)
  {
   	exit(0);      
  }
  
  if ((key == 'x')||(key = 'X'))
  {
  
  }
}
//****************************************************************************
// Timed Interrupts
//****************************************************************************

//Timer function....called each second
void TimerUpdate(int value){
  //game clock
  
  /*
   gnTimeLeft -= value; //one second countdown timer
  if (gnTimeLeft<1) {
    gnTimeLeft=0;
  }
  */
  //keep calling timer each second
  glutTimerFunc(1000,TimerUpdate,1);
}

/************************************************************************
  main() - This program begins here!  
************************************************************************/
int main(int argc, char **argv)
{

  //setup event logging
  gEventLog.SetFilename("log2.txt");
  gEventLog.LogData("**********************************",0);
  gEventLog.LogData("Start of Program.",0);
  gEventLog.LogData("**********************************",0);
  InitializeVariables();

  //OpenGL/GLUT graphical outputs
  gEventLog.LogData("Initialize OpenGL/GLUT Graphics.",0);
  glutInit(&argc, argv);
  glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
  glutInitWindowSize(800,600);
  glutInitWindowPosition(0,0);
  glutCreateWindow(prog.program_name.c_str());
  glutSetCursor(GLUT_CURSOR_NONE);
  glutDisplayFunc(RenderScene);
  glutReshapeFunc(ResizeWindow);
  InitializeGraphics();

  //OpenGL/GLUT inputs - keyboard and mouse
  gEventLog.LogData("Initialize OpenGL/GLUT Keyboard and Mouse.",0);
  glutKeyboardFunc(PressNormalKey);
  glutSpecialFunc(PressExtendedKey);
  glutSpecialUpFunc(ReleaseExtendedKey);     
  glutPassiveMotionFunc(MousePassiveMotion);
  glutMouseFunc(MouseFunction);
    
  //Miscellaneous stuff
  gEventLog.LogData("Initialize Misc. Stuff.",0);
  glutIdleFunc(RenderScene);
  glutTimerFunc(1000,TimerUpdate,1);

  //GLUT Main loop
  gEventLog.LogData("Begin glutMainLoop().",0);
  glutMainLoop();
}


