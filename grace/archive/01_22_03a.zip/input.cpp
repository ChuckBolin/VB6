/*******************************************************************************
 INPUT.CPP
 Programmer: Chuck Bolin, 2003
 Purpose:    All input: mouse, keyboard comes here for processing.
*******************************************************************************/

//Include files
#include "input.h"


void CInput::ProcessInput (PROGRAMINPUT input){
  switch(input.event){
    case INPUT_PASSIVE_MOUSE:
      break;
    case INPUT_ACTIVE_MOUSE:
      break;
    case INPUT_EXTENDED_KEY_DOWN:
      break;
    case INPUT_EXTENDED_KEY_UP:
      ExtendedKeyUp(input);
      break;
    case INPUT_NORMAL_KEY_DOWN:
      NormalKeyDown(input);
      break;
    case INPUT_TIMER:
      break;
  }
}

void CInput::PassiveMouse(PROGRAMINPUT input){

}

void CInput::ActiveMouse(PROGRAMINPUT input){

}

void CInput::ExtendedKeyDown(PROGRAMINPUT input){

}

void CInput::ExtendedKeyUp(PROGRAMINPUT input){
 
  if (gGame.GetGameMode() == GAMEMODE_CONFIG){
 
  }
 
  if (gGame.GetGameMode() == GAMEMODE_PLAY){

    switch(input.key){
	    case GLUT_KEY_LEFT : gGraphics.sidestep = 0;break;
		  case GLUT_KEY_RIGHT :gGraphics.sidestep = 0;break;
		  case GLUT_KEY_UP : gGraphics.step = 0;break;
		  case GLUT_KEY_DOWN : gGraphics.step = 0;break;
    }
  }
}

void CInput::Timer(PROGRAMINPUT input){

}

//Normal key is pressed down
void CInput::NormalKeyDown(PROGRAMINPUT input){
  
  if (input.uckey == 27){
    exit(0);
  }

}
