#define GLUT_DISABLE_ATEXIT_HACK
#include <gl\gl.h>
#include <gl\glut.h>
#include <gl\glu.h>
#include <cstdlib>
#include <ctime>
#include "fperson.h"
#include "graphics.h"

void DrawAsteroids(void);
void DrawSphere(void);
void DrawCloud(void);
void DrawHeadingIndicator(float, float);

